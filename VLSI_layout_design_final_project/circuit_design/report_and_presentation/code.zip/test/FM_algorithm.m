%% 本程序可以用来证明当cut每个元素符号与特征值较小的特征向量一致时，对应的cut会是比较小的值
function best_gain = FM_algorithm(num,percent,L,num_pass,num_initial_cut)
best_gain = num * num;
for i = 1:num_initial_cut
    cut = initialize_cut(num, percent);
    [gain,cut] = one_initial_cut(L,cut,num,percent,num_pass);
    if gain < best_gain
		best_gain = gain;
	end
end

    
			
		
    

