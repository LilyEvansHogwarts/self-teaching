function [best_gain,best_cut] = one_initial_cut(L,cut,num,percent,num_pass)
best_gain = num * num;
best_cut = zeros(num,1);
for i = 1:num_pass
	vertex = initialize_vertex(L,cut,num);
	[length,bucket] = initialize_bucket(vertex,num);
	[cut,gain] = pass(L,vertex,length,bucket,num,percent);
    if gain < best_gain
        best_gain = gain;
        best_cut = cut;
    end
end

