function [cut, best_gain] = pass(L,vertex,length,bucket,num,percent)
cut = zeros(num,1);
best_gain = num * num;
for i = 1:num
	[vertex,length,bucket] = vertex_process(L,vertex,length,bucket,num,percent);
	gain = vertex(:,4)' * L * vertex(:,4) / 4;
	if gain < best_gain
		cut = vertex(:,4);
		best_gain = gain;
	end
end
