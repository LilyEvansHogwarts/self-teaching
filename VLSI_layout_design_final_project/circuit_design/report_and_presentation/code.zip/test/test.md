## test3

test3是在test1和FM_algorithm的基础上进行对比，对比其运算所需要的时间和结果精度;
